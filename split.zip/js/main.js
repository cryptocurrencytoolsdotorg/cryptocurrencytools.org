var selectedCoin = 'btc';
var currentPage = 'pIntro';

var config = {
	    coinUnitPlaces: 12,
	    txMinConfirms: 10,
	    coinSymbol: 'XMR',
	    openAliasPrefix: "xmr",
	    coinName: 'Monero',
	    coinUriPrefix: 'monero:',
	    addressPrefix: 18,
	    integratedAddressPrefix: 19,
	    feePerKB: new BigInteger('10000000000'),
	    dustThreshold: new BigInteger('1000000'),
	    txChargeRatio: 0.5,
	    defaultMixin: 3,
	    idleTimeout: 10,
	    idleWarningDuration: 20,
	    maxBlockNumber: 500000000,
	    avgBlockTime: 60,
	    debugMode: false
	};

showInfo = function(msg) {
	var fb = $('#' + currentPage + ' .feedback');
	fb.html(msg);
	fb.attr('class', 'feedback info');
	fb.css('display', 'block');
	console.info(msg);
}

showError = function(msg) {
	var fb = $('#' + currentPage + ' .feedback');
	fb.html(msg);
	fb.attr('class', 'feedback fail');
	fb.css('display', 'block');
	console.error(fb, currentPage, msg);
}

showSuccess = function(msg) {
	var fb = $('#' + currentPage + ' .feedback');
	fb.html(msg);
	fb.attr('class', 'feedback ok');
	fb.css('display', 'block');
	console.info(msg);
}

checkXmrBase58 = function(data) {
	var r = "[123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz]";
	data = data.replace(/[123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz]/g, '');
	if (data !== '') {
		var chars = Array.from(new Set(data.split('')));
		data = chars.join(', ');
		return data; 
	}
	return '';
}

checkHex = function(data, len=0) {
	var r = '';
	if (len !== 0) {
		r = "^[0-9a-fA-F]$";
	} else {
		r = "^[0-9a-fA-F]{" + len + "}$";
	}
	var exp = new RegExp(r);
	return exp.test(data);
}

showPage = function(pNew, focus='', hint='', reverse=false) {
	if (pNew === currentPage) return;
	var pOld = currentPage;
	currentPage = pNew; 
	var rOld = $('#' + pOld);
	var rNew = $('#' + pNew);

	var fb = $('#' + currentPage + ' .feedback');
	fb.html(hint);
	fb.attr('class', 'feedback info');
	fb.css('display', 'block');

    if (rOld.length == 0) {
    	console.error('Page ', pOld, ' not found.');
    } else if (rNew.length == 0) {
    	console.error('Page ', pNew, ' not found.');
    } else {
		console.log("Hiding ", pOld, " showing ", pNew);

		if (reverse) {
			rNew.css('left', '-150%');
			rNew.show();
			//if (focus !== '') $('#' + focus).delay(500).focus();
			rOld.animate({left: '+150%', opacity: '0%'}, 500);
			rNew.animate({left: '10%', opacity: '100%'}, 500);
		} else {
			rNew.css('left', '+150%');
			rNew.show();
			//if (focus !== '') $('#' + focus).delay(500).focus();
			rOld.animate({left: '-150%', opacity: '0%'}, 500);
			rNew.animate({left: '10%', opacity: '100%'}, 500);
		}
	}

    if (currentPage === 'pIntro') {
    	$('#donate').show();
    } else {
    	$('#donate').hide();
    }
}

mainMenuShow = function() {
	if (currentPage === 'pIntro') {
		showPage("pMainMenu");
	} else if (currentPage !== 'pMainMenu') {
		showPage("pMainMenu", '', '', true);
	}

	$('#btcDrawer').hide();
	$('#xmrDrawer').hide();
	$('#mmTitle').html("Pick the currency...");

	if (selectedCoin == 'xmr') {
		xmrSelect();
	} else { 
		btcSelect();
	}
}

btcSelect = function() {
	selectedCoin = 'btc';
	$('#chkXmr').attr('checked', false);
	$('#chkBtc').attr('checked', true);
	$('#xmrDrawer').hide();
	$('#btcDrawer').show();
	$('#mmTitle').html("Select tool");
}
xmrSelect = function() {
	selectedCoin = 'xmr';
	$('#chkBtc').attr('checked', false);
	$('#chkXmr').attr('checked', true);
	$('#btcDrawer').hide();
	$('#xmrDrawer').show();
	$('#mmTitle').html("Select tool");
}

$(function() {
	$('.page').hide();
	$('#pIntro').show();
	$('#loading').delay(250).fadeOut(250);
	//$('#loading').remove();
});

